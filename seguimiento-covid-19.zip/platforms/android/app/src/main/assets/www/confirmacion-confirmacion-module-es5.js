function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["confirmacion-confirmacion-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/confirmacion/confirmacion.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/confirmacion/confirmacion.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppConfirmacionConfirmacionPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- <ion-content>\n<img src=\"assets/elsalvador.jpg\" style=\"width: 100%;\" alt=\"\">\n\n<div class=\"ion-padding\">\n  <div class=\"heading\">\n      <div class=\"success-checkmark\">\n          <div class=\"check-icon\">\n            <span class=\"icon-line line-tip\"></span>\n            <span class=\"icon-line line-long\"></span>\n            <div class=\"icon-circle\"></div>\n            <div class=\"icon-fix\"></div>\n          </div>\n        </div>\n    <h4>Se ha enviado tu informe diario</h4>\n    <p>Recuerda mantenerte alejado de las demas personas y evita salir de casa.</p>\n    <p>Si tus sintomas persisten o presentas complicaciones, presentate inmediatamente a un centro\n      de salud o llama al 132.\n    </p>\n  </div>\n</div>\n\n</ion-content>\n<ion-footer class=\"ion-no-border\">\n    <ion-toolbar>\n      <div class=\"ion-padding\">\n          <ion-button [routerLink]=\"['/Inicio']\" expand=\"block\" color=\"primary\">\n              Continuar\n            </ion-button>\n      </div>\n    </ion-toolbar>\n  </ion-footer> -->\n  <ion-content>\n    <div class=\"ion-padding\" style=\"background-color: #1E265C; color:white; height:100%; padding-top: 45px;\">\n      <img src=\"assets/minsal-blanco.png\" style=\"display: block; margin: auto; margin-bottom: 25px\" height=\"100\" alt=\"\">\n      <h1>Gracias por tu ayuda y vital contribución al combate del COVID-19</h1>\n      <p style=\"color: #d4d4d4;\">Recuerda mantenerte alejado de las demas personas y evita salir de casa. Si tus síntomas persisten o presentas complicaciones, presentate inmediatamente a un centro\n          de salud o llama al <strong>132</strong>.</p>\n    </div>\n  </ion-content>\n  <ion-footer class=\"ion-no-border\">\n      <ion-toolbar>\n        <div class=\"ion-padding\" style=\"background-color: #1E265C\">\n            <ion-button [routerLink]=\"['/main/Inicio']\" expand=\"block\" color=\"light\">\n                Continuar\n              </ion-button>\n        </div>\n      </ion-toolbar>\n    </ion-footer>\n";
    /***/
  },

  /***/
  "./src/app/confirmacion/confirmacion-routing.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/confirmacion/confirmacion-routing.module.ts ***!
    \*************************************************************/

  /*! exports provided: ConfirmacionPageRoutingModule */

  /***/
  function srcAppConfirmacionConfirmacionRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ConfirmacionPageRoutingModule", function () {
      return ConfirmacionPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _confirmacion_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./confirmacion.page */
    "./src/app/confirmacion/confirmacion.page.ts");

    var routes = [{
      path: '',
      component: _confirmacion_page__WEBPACK_IMPORTED_MODULE_3__["ConfirmacionPage"]
    }];

    var ConfirmacionPageRoutingModule = function ConfirmacionPageRoutingModule() {
      _classCallCheck(this, ConfirmacionPageRoutingModule);
    };

    ConfirmacionPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ConfirmacionPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/confirmacion/confirmacion.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/confirmacion/confirmacion.module.ts ***!
    \*****************************************************/

  /*! exports provided: ConfirmacionPageModule */

  /***/
  function srcAppConfirmacionConfirmacionModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ConfirmacionPageModule", function () {
      return ConfirmacionPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _confirmacion_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./confirmacion-routing.module */
    "./src/app/confirmacion/confirmacion-routing.module.ts");
    /* harmony import */


    var _confirmacion_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./confirmacion.page */
    "./src/app/confirmacion/confirmacion.page.ts");

    var ConfirmacionPageModule = function ConfirmacionPageModule() {
      _classCallCheck(this, ConfirmacionPageModule);
    };

    ConfirmacionPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _confirmacion_routing_module__WEBPACK_IMPORTED_MODULE_5__["ConfirmacionPageRoutingModule"]],
      declarations: [_confirmacion_page__WEBPACK_IMPORTED_MODULE_6__["ConfirmacionPage"]]
    })], ConfirmacionPageModule);
    /***/
  },

  /***/
  "./src/app/confirmacion/confirmacion.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/confirmacion/confirmacion.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppConfirmacionConfirmacionPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".heading {\n  text-align: center;\n}\n\n.heading p {\n  font-size: 15px;\n}\n\n.success-checkmark {\n  width: 80px;\n  height: 115px;\n  margin: 0 auto;\n}\n\n.success-checkmark .check-icon {\n  width: 80px;\n  height: 80px;\n  position: relative;\n  border-radius: 50%;\n  box-sizing: content-box;\n  border: 4px solid #4CAF50;\n}\n\n.success-checkmark .check-icon::before {\n  top: 3px;\n  left: -2px;\n  width: 30px;\n  transform-origin: 100% 50%;\n  border-radius: 100px 0 0 100px;\n}\n\n.success-checkmark .check-icon::after {\n  top: 0;\n  left: 30px;\n  width: 60px;\n  transform-origin: 0 50%;\n  border-radius: 0 100px 100px 0;\n  -webkit-animation: rotate-circle 4.25s ease-in;\n          animation: rotate-circle 4.25s ease-in;\n}\n\n.success-checkmark .check-icon::before, .success-checkmark .check-icon::after {\n  content: \"\";\n  height: 100px;\n  position: absolute;\n  background: #FFFFFF;\n  transform: rotate(-45deg);\n}\n\n.success-checkmark .check-icon .icon-line {\n  height: 5px;\n  background-color: #4CAF50;\n  display: block;\n  border-radius: 2px;\n  position: absolute;\n  z-index: 10;\n}\n\n.success-checkmark .check-icon .icon-line.line-tip {\n  top: 46px;\n  left: 14px;\n  width: 25px;\n  transform: rotate(45deg);\n  -webkit-animation: icon-line-tip 0.75s;\n          animation: icon-line-tip 0.75s;\n}\n\n.success-checkmark .check-icon .icon-line.line-long {\n  top: 38px;\n  right: 8px;\n  width: 47px;\n  transform: rotate(-45deg);\n  -webkit-animation: icon-line-long 0.75s;\n          animation: icon-line-long 0.75s;\n}\n\n.success-checkmark .check-icon .icon-circle {\n  top: -4px;\n  left: -4px;\n  z-index: 10;\n  width: 80px;\n  height: 80px;\n  border-radius: 50%;\n  position: absolute;\n  box-sizing: content-box;\n  border: 4px solid rgba(76, 175, 80, 0.5);\n}\n\n.success-checkmark .check-icon .icon-fix {\n  top: 8px;\n  width: 5px;\n  left: 26px;\n  z-index: 1;\n  height: 85px;\n  position: absolute;\n  transform: rotate(-45deg);\n  background-color: #FFFFFF;\n}\n\n@-webkit-keyframes rotate-circle {\n  0% {\n    transform: rotate(-45deg);\n  }\n  5% {\n    transform: rotate(-45deg);\n  }\n  12% {\n    transform: rotate(-405deg);\n  }\n  100% {\n    transform: rotate(-405deg);\n  }\n}\n\n@keyframes rotate-circle {\n  0% {\n    transform: rotate(-45deg);\n  }\n  5% {\n    transform: rotate(-45deg);\n  }\n  12% {\n    transform: rotate(-405deg);\n  }\n  100% {\n    transform: rotate(-405deg);\n  }\n}\n\n@-webkit-keyframes icon-line-tip {\n  0% {\n    width: 0;\n    left: 1px;\n    top: 19px;\n  }\n  54% {\n    width: 0;\n    left: 1px;\n    top: 19px;\n  }\n  70% {\n    width: 50px;\n    left: -8px;\n    top: 37px;\n  }\n  84% {\n    width: 17px;\n    left: 21px;\n    top: 48px;\n  }\n  100% {\n    width: 25px;\n    left: 14px;\n    top: 45px;\n  }\n}\n\n@keyframes icon-line-tip {\n  0% {\n    width: 0;\n    left: 1px;\n    top: 19px;\n  }\n  54% {\n    width: 0;\n    left: 1px;\n    top: 19px;\n  }\n  70% {\n    width: 50px;\n    left: -8px;\n    top: 37px;\n  }\n  84% {\n    width: 17px;\n    left: 21px;\n    top: 48px;\n  }\n  100% {\n    width: 25px;\n    left: 14px;\n    top: 45px;\n  }\n}\n\n@-webkit-keyframes icon-line-long {\n  0% {\n    width: 0;\n    right: 46px;\n    top: 54px;\n  }\n  65% {\n    width: 0;\n    right: 46px;\n    top: 54px;\n  }\n  84% {\n    width: 55px;\n    right: 0px;\n    top: 35px;\n  }\n  100% {\n    width: 47px;\n    right: 8px;\n    top: 38px;\n  }\n}\n\n@keyframes icon-line-long {\n  0% {\n    width: 0;\n    right: 46px;\n    top: 54px;\n  }\n  65% {\n    width: 0;\n    right: 46px;\n    top: 54px;\n  }\n  84% {\n    width: 55px;\n    right: 0px;\n    top: 35px;\n  }\n  100% {\n    width: 47px;\n    right: 8px;\n    top: 38px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9yb290L0RvY3VtZW50b3MvUHJveWVjdG9zL0lvbmljL3NlZ3VpbWllbnRvLWNvdmlkLTE5L3NyYy9hcHAvY29uZmlybWFjaW9uL2NvbmZpcm1hY2lvbi5wYWdlLnNjc3MiLCJzcmMvYXBwL2NvbmZpcm1hY2lvbi9jb25maXJtYWNpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7QUNDSjs7QURDQTtFQUNJLGVBQUE7QUNFSjs7QURDQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtBQ0VKOztBREFJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSx5QkFBQTtBQ0VSOztBREFRO0VBQ0ksUUFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsMEJBQUE7RUFDQSw4QkFBQTtBQ0VaOztBRENRO0VBQ0ksTUFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsdUJBQUE7RUFDQSw4QkFBQTtFQUNBLDhDQUFBO1VBQUEsc0NBQUE7QUNDWjs7QURFUTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FDQVo7O0FER1E7RUFDSSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUNEWjs7QURHWTtFQUNJLFNBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLHdCQUFBO0VBQ0Esc0NBQUE7VUFBQSw4QkFBQTtBQ0RoQjs7QURJWTtFQUNJLFNBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLHlCQUFBO0VBQ0EsdUNBQUE7VUFBQSwrQkFBQTtBQ0ZoQjs7QURNUTtFQUNJLFNBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0Esd0NBQUE7QUNKWjs7QURPUTtFQUNJLFFBQUE7RUFDQSxVQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLHlCQUFBO0FDTFo7O0FEVUE7RUFDSTtJQUNJLHlCQUFBO0VDUE47RURTRTtJQUNJLHlCQUFBO0VDUE47RURTRTtJQUNJLDBCQUFBO0VDUE47RURTRTtJQUNJLDBCQUFBO0VDUE47QUFDRjs7QURMQTtFQUNJO0lBQ0kseUJBQUE7RUNQTjtFRFNFO0lBQ0kseUJBQUE7RUNQTjtFRFNFO0lBQ0ksMEJBQUE7RUNQTjtFRFNFO0lBQ0ksMEJBQUE7RUNQTjtBQUNGOztBRFVBO0VBQ0k7SUFDSSxRQUFBO0lBQ0EsU0FBQTtJQUNBLFNBQUE7RUNSTjtFRFVFO0lBQ0ksUUFBQTtJQUNBLFNBQUE7SUFDQSxTQUFBO0VDUk47RURVRTtJQUNJLFdBQUE7SUFDQSxVQUFBO0lBQ0EsU0FBQTtFQ1JOO0VEVUU7SUFDSSxXQUFBO0lBQ0EsVUFBQTtJQUNBLFNBQUE7RUNSTjtFRFVFO0lBQ0ksV0FBQTtJQUNBLFVBQUE7SUFDQSxTQUFBO0VDUk47QUFDRjs7QURqQkE7RUFDSTtJQUNJLFFBQUE7SUFDQSxTQUFBO0lBQ0EsU0FBQTtFQ1JOO0VEVUU7SUFDSSxRQUFBO0lBQ0EsU0FBQTtJQUNBLFNBQUE7RUNSTjtFRFVFO0lBQ0ksV0FBQTtJQUNBLFVBQUE7SUFDQSxTQUFBO0VDUk47RURVRTtJQUNJLFdBQUE7SUFDQSxVQUFBO0lBQ0EsU0FBQTtFQ1JOO0VEVUU7SUFDSSxXQUFBO0lBQ0EsVUFBQTtJQUNBLFNBQUE7RUNSTjtBQUNGOztBRFdBO0VBQ0k7SUFDSSxRQUFBO0lBQ0EsV0FBQTtJQUNBLFNBQUE7RUNUTjtFRFdFO0lBQ0ksUUFBQTtJQUNBLFdBQUE7SUFDQSxTQUFBO0VDVE47RURXRTtJQUNJLFdBQUE7SUFDQSxVQUFBO0lBQ0EsU0FBQTtFQ1ROO0VEV0U7SUFDSSxXQUFBO0lBQ0EsVUFBQTtJQUNBLFNBQUE7RUNUTjtBQUNGOztBRFhBO0VBQ0k7SUFDSSxRQUFBO0lBQ0EsV0FBQTtJQUNBLFNBQUE7RUNUTjtFRFdFO0lBQ0ksUUFBQTtJQUNBLFdBQUE7SUFDQSxTQUFBO0VDVE47RURXRTtJQUNJLFdBQUE7SUFDQSxVQUFBO0lBQ0EsU0FBQTtFQ1ROO0VEV0U7SUFDSSxXQUFBO0lBQ0EsVUFBQTtJQUNBLFNBQUE7RUNUTjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvY29uZmlybWFjaW9uL2NvbmZpcm1hY2lvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGluZyB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuLmhlYWRpbmcgcCB7XG4gICAgZm9udC1zaXplOiAxNXB4O1xufVxuXG4uc3VjY2Vzcy1jaGVja21hcmsge1xuICAgIHdpZHRoOiA4MHB4O1xuICAgIGhlaWdodDogMTE1cHg7XG4gICAgbWFyZ2luOiAwIGF1dG87XG4gICAgXG4gICAgLmNoZWNrLWljb24ge1xuICAgICAgICB3aWR0aDogODBweDtcbiAgICAgICAgaGVpZ2h0OiA4MHB4O1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgYm94LXNpemluZzogY29udGVudC1ib3g7XG4gICAgICAgIGJvcmRlcjogNHB4IHNvbGlkICM0Q0FGNTA7XG4gICAgICAgIFxuICAgICAgICAmOjpiZWZvcmUge1xuICAgICAgICAgICAgdG9wOiAzcHg7XG4gICAgICAgICAgICBsZWZ0OiAtMnB4O1xuICAgICAgICAgICAgd2lkdGg6IDMwcHg7XG4gICAgICAgICAgICB0cmFuc2Zvcm0tb3JpZ2luOiAxMDAlIDUwJTtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMHB4IDAgMCAxMDBweDtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgJjo6YWZ0ZXIge1xuICAgICAgICAgICAgdG9wOiAwO1xuICAgICAgICAgICAgbGVmdDogMzBweDtcbiAgICAgICAgICAgIHdpZHRoOiA2MHB4O1xuICAgICAgICAgICAgdHJhbnNmb3JtLW9yaWdpbjogMCA1MCU7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAwIDEwMHB4IDEwMHB4IDA7XG4gICAgICAgICAgICBhbmltYXRpb246IHJvdGF0ZS1jaXJjbGUgNC4yNXMgZWFzZS1pbjtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgJjo6YmVmb3JlLCAmOjphZnRlciB7XG4gICAgICAgICAgICBjb250ZW50OiAnJztcbiAgICAgICAgICAgIGhlaWdodDogMTAwcHg7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjRkZGRkZGO1xuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoLTQ1ZGVnKTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLmljb24tbGluZSB7XG4gICAgICAgICAgICBoZWlnaHQ6IDVweDtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICM0Q0FGNTA7XG4gICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDJweDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgICAgIHotaW5kZXg6IDEwO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAmLmxpbmUtdGlwIHtcbiAgICAgICAgICAgICAgICB0b3A6IDQ2cHg7XG4gICAgICAgICAgICAgICAgbGVmdDogMTRweDtcbiAgICAgICAgICAgICAgICB3aWR0aDogMjVweDtcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XG4gICAgICAgICAgICAgICAgYW5pbWF0aW9uOiBpY29uLWxpbmUtdGlwIDAuNzVzO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgICAgICAmLmxpbmUtbG9uZyB7XG4gICAgICAgICAgICAgICAgdG9wOiAzOHB4O1xuICAgICAgICAgICAgICAgIHJpZ2h0OiA4cHg7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDQ3cHg7XG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoLTQ1ZGVnKTtcbiAgICAgICAgICAgICAgICBhbmltYXRpb246IGljb24tbGluZS1sb25nIDAuNzVzO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAuaWNvbi1jaXJjbGUge1xuICAgICAgICAgICAgdG9wOiAtNHB4O1xuICAgICAgICAgICAgbGVmdDogLTRweDtcbiAgICAgICAgICAgIHotaW5kZXg6IDEwO1xuICAgICAgICAgICAgd2lkdGg6IDgwcHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDgwcHg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICBib3gtc2l6aW5nOiBjb250ZW50LWJveDtcbiAgICAgICAgICAgIGJvcmRlcjogNHB4IHNvbGlkIHJnYmEoNzYsIDE3NSwgODAsIC41KTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLmljb24tZml4IHtcbiAgICAgICAgICAgIHRvcDogOHB4O1xuICAgICAgICAgICAgd2lkdGg6IDVweDtcbiAgICAgICAgICAgIGxlZnQ6IDI2cHg7XG4gICAgICAgICAgICB6LWluZGV4OiAxO1xuICAgICAgICAgICAgaGVpZ2h0OiA4NXB4O1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoLTQ1ZGVnKTtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNGRkZGRkY7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbkBrZXlmcmFtZXMgcm90YXRlLWNpcmNsZSB7XG4gICAgMCUge1xuICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtNDVkZWcpO1xuICAgIH1cbiAgICA1JSB7XG4gICAgICAgIHRyYW5zZm9ybTogcm90YXRlKC00NWRlZyk7XG4gICAgfVxuICAgIDEyJSB7XG4gICAgICAgIHRyYW5zZm9ybTogcm90YXRlKC00MDVkZWcpO1xuICAgIH1cbiAgICAxMDAlIHtcbiAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoLTQwNWRlZyk7XG4gICAgfVxufVxuXG5Aa2V5ZnJhbWVzIGljb24tbGluZS10aXAge1xuICAgIDAlIHtcbiAgICAgICAgd2lkdGg6IDA7XG4gICAgICAgIGxlZnQ6IDFweDtcbiAgICAgICAgdG9wOiAxOXB4O1xuICAgIH1cbiAgICA1NCUge1xuICAgICAgICB3aWR0aDogMDtcbiAgICAgICAgbGVmdDogMXB4O1xuICAgICAgICB0b3A6IDE5cHg7XG4gICAgfVxuICAgIDcwJSB7XG4gICAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgICBsZWZ0OiAtOHB4O1xuICAgICAgICB0b3A6IDM3cHg7XG4gICAgfVxuICAgIDg0JSB7XG4gICAgICAgIHdpZHRoOiAxN3B4O1xuICAgICAgICBsZWZ0OiAyMXB4O1xuICAgICAgICB0b3A6IDQ4cHg7XG4gICAgfVxuICAgIDEwMCUge1xuICAgICAgICB3aWR0aDogMjVweDtcbiAgICAgICAgbGVmdDogMTRweDtcbiAgICAgICAgdG9wOiA0NXB4O1xuICAgIH1cbn1cblxuQGtleWZyYW1lcyBpY29uLWxpbmUtbG9uZyB7XG4gICAgMCUge1xuICAgICAgICB3aWR0aDogMDtcbiAgICAgICAgcmlnaHQ6IDQ2cHg7XG4gICAgICAgIHRvcDogNTRweDtcbiAgICB9XG4gICAgNjUlIHtcbiAgICAgICAgd2lkdGg6IDA7XG4gICAgICAgIHJpZ2h0OiA0NnB4O1xuICAgICAgICB0b3A6IDU0cHg7XG4gICAgfVxuICAgIDg0JSB7XG4gICAgICAgIHdpZHRoOiA1NXB4O1xuICAgICAgICByaWdodDogMHB4O1xuICAgICAgICB0b3A6IDM1cHg7XG4gICAgfVxuICAgIDEwMCUge1xuICAgICAgICB3aWR0aDogNDdweDtcbiAgICAgICAgcmlnaHQ6IDhweDtcbiAgICAgICAgdG9wOiAzOHB4O1xuICAgIH1cbn0iLCIuaGVhZGluZyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmhlYWRpbmcgcCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cblxuLnN1Y2Nlc3MtY2hlY2ttYXJrIHtcbiAgd2lkdGg6IDgwcHg7XG4gIGhlaWdodDogMTE1cHg7XG4gIG1hcmdpbjogMCBhdXRvO1xufVxuLnN1Y2Nlc3MtY2hlY2ttYXJrIC5jaGVjay1pY29uIHtcbiAgd2lkdGg6IDgwcHg7XG4gIGhlaWdodDogODBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGJveC1zaXppbmc6IGNvbnRlbnQtYm94O1xuICBib3JkZXI6IDRweCBzb2xpZCAjNENBRjUwO1xufVxuLnN1Y2Nlc3MtY2hlY2ttYXJrIC5jaGVjay1pY29uOjpiZWZvcmUge1xuICB0b3A6IDNweDtcbiAgbGVmdDogLTJweDtcbiAgd2lkdGg6IDMwcHg7XG4gIHRyYW5zZm9ybS1vcmlnaW46IDEwMCUgNTAlO1xuICBib3JkZXItcmFkaXVzOiAxMDBweCAwIDAgMTAwcHg7XG59XG4uc3VjY2Vzcy1jaGVja21hcmsgLmNoZWNrLWljb246OmFmdGVyIHtcbiAgdG9wOiAwO1xuICBsZWZ0OiAzMHB4O1xuICB3aWR0aDogNjBweDtcbiAgdHJhbnNmb3JtLW9yaWdpbjogMCA1MCU7XG4gIGJvcmRlci1yYWRpdXM6IDAgMTAwcHggMTAwcHggMDtcbiAgYW5pbWF0aW9uOiByb3RhdGUtY2lyY2xlIDQuMjVzIGVhc2UtaW47XG59XG4uc3VjY2Vzcy1jaGVja21hcmsgLmNoZWNrLWljb246OmJlZm9yZSwgLnN1Y2Nlc3MtY2hlY2ttYXJrIC5jaGVjay1pY29uOjphZnRlciB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIGhlaWdodDogMTAwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYmFja2dyb3VuZDogI0ZGRkZGRjtcbiAgdHJhbnNmb3JtOiByb3RhdGUoLTQ1ZGVnKTtcbn1cbi5zdWNjZXNzLWNoZWNrbWFyayAuY2hlY2staWNvbiAuaWNvbi1saW5lIHtcbiAgaGVpZ2h0OiA1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICM0Q0FGNTA7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBib3JkZXItcmFkaXVzOiAycHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogMTA7XG59XG4uc3VjY2Vzcy1jaGVja21hcmsgLmNoZWNrLWljb24gLmljb24tbGluZS5saW5lLXRpcCB7XG4gIHRvcDogNDZweDtcbiAgbGVmdDogMTRweDtcbiAgd2lkdGg6IDI1cHg7XG4gIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcbiAgYW5pbWF0aW9uOiBpY29uLWxpbmUtdGlwIDAuNzVzO1xufVxuLnN1Y2Nlc3MtY2hlY2ttYXJrIC5jaGVjay1pY29uIC5pY29uLWxpbmUubGluZS1sb25nIHtcbiAgdG9wOiAzOHB4O1xuICByaWdodDogOHB4O1xuICB3aWR0aDogNDdweDtcbiAgdHJhbnNmb3JtOiByb3RhdGUoLTQ1ZGVnKTtcbiAgYW5pbWF0aW9uOiBpY29uLWxpbmUtbG9uZyAwLjc1cztcbn1cbi5zdWNjZXNzLWNoZWNrbWFyayAuY2hlY2staWNvbiAuaWNvbi1jaXJjbGUge1xuICB0b3A6IC00cHg7XG4gIGxlZnQ6IC00cHg7XG4gIHotaW5kZXg6IDEwO1xuICB3aWR0aDogODBweDtcbiAgaGVpZ2h0OiA4MHB4O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm94LXNpemluZzogY29udGVudC1ib3g7XG4gIGJvcmRlcjogNHB4IHNvbGlkIHJnYmEoNzYsIDE3NSwgODAsIDAuNSk7XG59XG4uc3VjY2Vzcy1jaGVja21hcmsgLmNoZWNrLWljb24gLmljb24tZml4IHtcbiAgdG9wOiA4cHg7XG4gIHdpZHRoOiA1cHg7XG4gIGxlZnQ6IDI2cHg7XG4gIHotaW5kZXg6IDE7XG4gIGhlaWdodDogODVweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0cmFuc2Zvcm06IHJvdGF0ZSgtNDVkZWcpO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkZGRkZGO1xufVxuXG5Aa2V5ZnJhbWVzIHJvdGF0ZS1jaXJjbGUge1xuICAwJSB7XG4gICAgdHJhbnNmb3JtOiByb3RhdGUoLTQ1ZGVnKTtcbiAgfVxuICA1JSB7XG4gICAgdHJhbnNmb3JtOiByb3RhdGUoLTQ1ZGVnKTtcbiAgfVxuICAxMiUge1xuICAgIHRyYW5zZm9ybTogcm90YXRlKC00MDVkZWcpO1xuICB9XG4gIDEwMCUge1xuICAgIHRyYW5zZm9ybTogcm90YXRlKC00MDVkZWcpO1xuICB9XG59XG5Aa2V5ZnJhbWVzIGljb24tbGluZS10aXAge1xuICAwJSB7XG4gICAgd2lkdGg6IDA7XG4gICAgbGVmdDogMXB4O1xuICAgIHRvcDogMTlweDtcbiAgfVxuICA1NCUge1xuICAgIHdpZHRoOiAwO1xuICAgIGxlZnQ6IDFweDtcbiAgICB0b3A6IDE5cHg7XG4gIH1cbiAgNzAlIHtcbiAgICB3aWR0aDogNTBweDtcbiAgICBsZWZ0OiAtOHB4O1xuICAgIHRvcDogMzdweDtcbiAgfVxuICA4NCUge1xuICAgIHdpZHRoOiAxN3B4O1xuICAgIGxlZnQ6IDIxcHg7XG4gICAgdG9wOiA0OHB4O1xuICB9XG4gIDEwMCUge1xuICAgIHdpZHRoOiAyNXB4O1xuICAgIGxlZnQ6IDE0cHg7XG4gICAgdG9wOiA0NXB4O1xuICB9XG59XG5Aa2V5ZnJhbWVzIGljb24tbGluZS1sb25nIHtcbiAgMCUge1xuICAgIHdpZHRoOiAwO1xuICAgIHJpZ2h0OiA0NnB4O1xuICAgIHRvcDogNTRweDtcbiAgfVxuICA2NSUge1xuICAgIHdpZHRoOiAwO1xuICAgIHJpZ2h0OiA0NnB4O1xuICAgIHRvcDogNTRweDtcbiAgfVxuICA4NCUge1xuICAgIHdpZHRoOiA1NXB4O1xuICAgIHJpZ2h0OiAwcHg7XG4gICAgdG9wOiAzNXB4O1xuICB9XG4gIDEwMCUge1xuICAgIHdpZHRoOiA0N3B4O1xuICAgIHJpZ2h0OiA4cHg7XG4gICAgdG9wOiAzOHB4O1xuICB9XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/confirmacion/confirmacion.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/confirmacion/confirmacion.page.ts ***!
    \***************************************************/

  /*! exports provided: ConfirmacionPage */

  /***/
  function srcAppConfirmacionConfirmacionPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ConfirmacionPage", function () {
      return ConfirmacionPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var ConfirmacionPage = /*#__PURE__*/function () {
      function ConfirmacionPage() {
        _classCallCheck(this, ConfirmacionPage);
      }

      _createClass(ConfirmacionPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return ConfirmacionPage;
    }();

    ConfirmacionPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-confirmacion',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./confirmacion.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/confirmacion/confirmacion.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./confirmacion.page.scss */
      "./src/app/confirmacion/confirmacion.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], ConfirmacionPage);
    /***/
  }
}]);
//# sourceMappingURL=confirmacion-confirmacion-module-es5.js.map