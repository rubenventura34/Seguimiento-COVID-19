(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["fiebre-fiebre-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/fiebre/fiebre.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/fiebre/fiebre.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<ion-content color=\"warning-light\">\n    <div class=\"container\">\n        <div class=\"ion-padding heading\">\n            <ion-text color=\"light\">\n                <h1><strong>¿Tienes Fiebre?</strong></h1>\n                <p>Dinos como te has sentido durante el dia.</p>\n            </ion-text>\n            \n          </div>\n          <div class=\"range-control\">\n              <ion-range mode=\"ios\" [(ngModel)]=\"rangeValue\" (touchmove)=\"changeStatus()\" min=\"1\" max=\"3\" step=\"1\" value=\"1\" snaps=\"true\" color=\"danger\">\n                  <ion-icon slot=\"start\" size=\"small\" color=\"danger\" name=\"thermometer-outline\"></ion-icon>\n                  <ion-icon slot=\"end\" color=\"danger\" name=\"thermometer-outline\"></ion-icon>\n              </ion-range>\n              <ion-text color=\"light\">\n                  <h3><strong>{{ estado }}</strong></h3>\n                  <h3><strong>{{ temperatura }}</strong></h3>\n              </ion-text>\n          </div>\n          \n          \n    </div>\n\n</ion-content>\n<ion-footer color=\"warning-light\" class=\"ion-no-border\">\n  <ion-toolbar color=\"warning-light\">\n    <div class=\"ion-padding\">\n        <ion-button (click)=\"siguiente()\" expand=\"block\" color=\"primary\">\n            Siguiente\n          </ion-button>\n    </div>\n  </ion-toolbar>\n</ion-footer>\n\n");

/***/ }),

/***/ "./src/app/fiebre/fiebre-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/fiebre/fiebre-routing.module.ts ***!
  \*************************************************/
/*! exports provided: FiebrePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiebrePageRoutingModule", function() { return FiebrePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _fiebre_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./fiebre.page */ "./src/app/fiebre/fiebre.page.ts");




const routes = [
    {
        path: '',
        component: _fiebre_page__WEBPACK_IMPORTED_MODULE_3__["FiebrePage"]
    }
];
let FiebrePageRoutingModule = class FiebrePageRoutingModule {
};
FiebrePageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], FiebrePageRoutingModule);



/***/ }),

/***/ "./src/app/fiebre/fiebre.module.ts":
/*!*****************************************!*\
  !*** ./src/app/fiebre/fiebre.module.ts ***!
  \*****************************************/
/*! exports provided: FiebrePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiebrePageModule", function() { return FiebrePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _fiebre_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./fiebre-routing.module */ "./src/app/fiebre/fiebre-routing.module.ts");
/* harmony import */ var _fiebre_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./fiebre.page */ "./src/app/fiebre/fiebre.page.ts");







let FiebrePageModule = class FiebrePageModule {
};
FiebrePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _fiebre_routing_module__WEBPACK_IMPORTED_MODULE_5__["FiebrePageRoutingModule"]
        ],
        declarations: [_fiebre_page__WEBPACK_IMPORTED_MODULE_6__["FiebrePage"]]
    })
], FiebrePageModule);



/***/ }),

/***/ "./src/app/fiebre/fiebre.page.scss":
/*!*****************************************!*\
  !*** ./src/app/fiebre/fiebre.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container {\n  text-align: center;\n}\n\n.range-control {\n  top: 40%;\n  right: 0;\n  left: 0;\n  position: absolute;\n  transform: translateY(40%);\n}\n\n.heading {\n  margin-top: 25px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9yb290L0RvY3VtZW50b3MvUHJveWVjdG9zL0lvbmljL3NlZ3VpbWllbnRvLWNvdmlkLTE5L3NyYy9hcHAvZmllYnJlL2ZpZWJyZS5wYWdlLnNjc3MiLCJzcmMvYXBwL2ZpZWJyZS9maWVicmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7QUNDSjs7QURDQTtFQUNJLFFBQUE7RUFDQSxRQUFBO0VBQ0EsT0FBQTtFQUNBLGtCQUFBO0VBQ0EsMEJBQUE7QUNFSjs7QURBQTtFQUNJLGdCQUFBO0FDR0oiLCJmaWxlIjoic3JjL2FwcC9maWVicmUvZmllYnJlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5yYW5nZS1jb250cm9sIHtcbiAgICB0b3A6IDQwJTtcbiAgICByaWdodDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoNDAlKTtcbn1cbi5oZWFkaW5nIHtcbiAgICBtYXJnaW4tdG9wOiAyNXB4O1xufSIsIi5jb250YWluZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5yYW5nZS1jb250cm9sIHtcbiAgdG9wOiA0MCU7XG4gIHJpZ2h0OiAwO1xuICBsZWZ0OiAwO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSg0MCUpO1xufVxuXG4uaGVhZGluZyB7XG4gIG1hcmdpbi10b3A6IDI1cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/fiebre/fiebre.page.ts":
/*!***************************************!*\
  !*** ./src/app/fiebre/fiebre.page.ts ***!
  \***************************************/
/*! exports provided: FiebrePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiebrePage", function() { return FiebrePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");




let FiebrePage = class FiebrePage {
    constructor(router, navCtrl, route) {
        this.router = router;
        this.navCtrl = navCtrl;
        this.route = route;
        this.rangeValue = 1;
        this.estado = "Normal";
        this.temperatura = "(~36°C-37,5°C)";
        this.route.queryParams.subscribe(params => {
            if (params) {
                this.dolor_de_cabeza = params.dolor_de_cabeza;
            }
        });
    }
    ngOnInit() {
    }
    changeStatus() {
        switch (this.rangeValue) {
            case 1:
                this.estado = "Normal";
                this.temperatura = "(~36°C-37,5°C)";
                break;
            case 2:
                this.estado = "Media";
                this.temperatura = "(~37,5°C-39,5°C)";
                break;
            case 3:
                this.estado = "Alta";
                this.temperatura = "(>39,5°C)";
                break;
            default:
                break;
        }
    }
    siguiente() {
        var navExtras = {
            queryParams: {
                dolor_de_cabeza: this.dolor_de_cabeza,
                fiebre: this.rangeValue
            }
        };
        this.navCtrl.navigateForward(["main/tos"], navExtras);
    }
};
FiebrePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
FiebrePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-fiebre',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./fiebre.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/fiebre/fiebre.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./fiebre.page.scss */ "./src/app/fiebre/fiebre.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
], FiebrePage);



/***/ })

}]);
//# sourceMappingURL=fiebre-fiebre-module-es2015.js.map