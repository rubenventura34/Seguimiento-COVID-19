function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tos-tos-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tos/tos.page.html":
  /*!*************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tos/tos.page.html ***!
    \*************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTosTosPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n<ion-content color=\"danger\">\n    <div class=\"container\">\n        <div class=\"ion-padding heading\">\n            <ion-text color=\"light\">\n                <h1><strong>¿Has Tosido?</strong></h1>\n                <p>Dinos como te has sentido durante el dia.</p>\n            </ion-text>\n            \n          </div>\n          <div class=\"range-control\">\n              <ion-range mode=\"ios\" [(ngModel)]=\"rangeValue\" (touchmove)=\"changeStatus()\" min=\"1\" max=\"3\" step=\"1\" value=\"1\" snaps=\"true\" color=\"warning\">\n                  <ion-icon slot=\"start\" size=\"small\" color=\"warning\" name=\"happy-outline\"></ion-icon>\n                  <ion-icon slot=\"end\" color=\"warning\" name=\"sad-outline\"></ion-icon>\n              </ion-range>\n              <ion-text color=\"light\">\n                  <h3><strong>{{ estado }}</strong></h3>\n              </ion-text>\n          </div>\n          \n          \n    </div>\n\n</ion-content>\n<ion-footer color=\"danger\" class=\"ion-no-border\">\n  <ion-toolbar color=\"danger\">\n    <div class=\"ion-padding\">\n        <ion-button (click)=\"siguiente()\" expand=\"block\" color=\"primary\">\n            Siguiente\n          </ion-button>\n    </div>\n  </ion-toolbar>\n</ion-footer>\n";
    /***/
  },

  /***/
  "./src/app/tos/tos-routing.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/tos/tos-routing.module.ts ***!
    \*******************************************/

  /*! exports provided: TosPageRoutingModule */

  /***/
  function srcAppTosTosRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TosPageRoutingModule", function () {
      return TosPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _tos_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./tos.page */
    "./src/app/tos/tos.page.ts");

    var routes = [{
      path: '',
      component: _tos_page__WEBPACK_IMPORTED_MODULE_3__["TosPage"]
    }];

    var TosPageRoutingModule = function TosPageRoutingModule() {
      _classCallCheck(this, TosPageRoutingModule);
    };

    TosPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], TosPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/tos/tos.module.ts":
  /*!***********************************!*\
    !*** ./src/app/tos/tos.module.ts ***!
    \***********************************/

  /*! exports provided: TosPageModule */

  /***/
  function srcAppTosTosModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TosPageModule", function () {
      return TosPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _tos_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./tos-routing.module */
    "./src/app/tos/tos-routing.module.ts");
    /* harmony import */


    var _tos_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./tos.page */
    "./src/app/tos/tos.page.ts");

    var TosPageModule = function TosPageModule() {
      _classCallCheck(this, TosPageModule);
    };

    TosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _tos_routing_module__WEBPACK_IMPORTED_MODULE_5__["TosPageRoutingModule"]],
      declarations: [_tos_page__WEBPACK_IMPORTED_MODULE_6__["TosPage"]]
    })], TosPageModule);
    /***/
  },

  /***/
  "./src/app/tos/tos.page.scss":
  /*!***********************************!*\
    !*** ./src/app/tos/tos.page.scss ***!
    \***********************************/

  /*! exports provided: default */

  /***/
  function srcAppTosTosPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".container {\n  text-align: center;\n}\n\n.range-control {\n  top: 40%;\n  right: 0;\n  left: 0;\n  position: absolute;\n  transform: translateY(40%);\n}\n\n.heading {\n  margin-top: 25px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9yb290L0RvY3VtZW50b3MvUHJveWVjdG9zL0lvbmljL3NlZ3VpbWllbnRvLWNvdmlkLTE5L3NyYy9hcHAvdG9zL3Rvcy5wYWdlLnNjc3MiLCJzcmMvYXBwL3Rvcy90b3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7QUNDSjs7QURDQTtFQUNJLFFBQUE7RUFDQSxRQUFBO0VBQ0EsT0FBQTtFQUNBLGtCQUFBO0VBQ0EsMEJBQUE7QUNFSjs7QURBQTtFQUNJLGdCQUFBO0FDR0oiLCJmaWxlIjoic3JjL2FwcC90b3MvdG9zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5yYW5nZS1jb250cm9sIHtcbiAgICB0b3A6IDQwJTtcbiAgICByaWdodDogMDtcbiAgICBsZWZ0OiAwO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoNDAlKTtcbn1cbi5oZWFkaW5nIHtcbiAgICBtYXJnaW4tdG9wOiAyNXB4O1xufSIsIi5jb250YWluZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5yYW5nZS1jb250cm9sIHtcbiAgdG9wOiA0MCU7XG4gIHJpZ2h0OiAwO1xuICBsZWZ0OiAwO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSg0MCUpO1xufVxuXG4uaGVhZGluZyB7XG4gIG1hcmdpbi10b3A6IDI1cHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/tos/tos.page.ts":
  /*!*********************************!*\
    !*** ./src/app/tos/tos.page.ts ***!
    \*********************************/

  /*! exports provided: TosPage */

  /***/
  function srcAppTosTosPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TosPage", function () {
      return TosPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var TosPage = /*#__PURE__*/function () {
      function TosPage(navCtrl, route) {
        var _this = this;

        _classCallCheck(this, TosPage);

        this.navCtrl = navCtrl;
        this.route = route;
        this.rangeValue = 1;
        this.estado = "No";
        this.route.queryParams.subscribe(function (params) {
          _this.dolor_de_cabeza = params.dolor_de_cabeza, _this.fiebre = params.fiebre;
        });
      }

      _createClass(TosPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "changeStatus",
        value: function changeStatus() {
          switch (this.rangeValue) {
            case 1:
              this.estado = "No";
              break;

            case 2:
              this.estado = "Poco";
              break;

            case 3:
              this.estado = "Mucho";
              break;

            default:
              break;
          }
        }
      }, {
        key: "siguiente",
        value: function siguiente() {
          var navExtras = {
            queryParams: {
              dolor_de_cabeza: this.dolor_de_cabeza,
              fiebre: this.fiebre,
              tos: this.rangeValue
            }
          };
          this.navCtrl.navigateForward(["main/otros"], navExtras);
        }
      }]);

      return TosPage;
    }();

    TosPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }];
    };

    TosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-tos',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./tos.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tos/tos.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./tos.page.scss */
      "./src/app/tos/tos.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])], TosPage);
    /***/
  }
}]);
//# sourceMappingURL=tos-tos-module-es5.js.map