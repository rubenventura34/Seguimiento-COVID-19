(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["inicio-inicio-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/inicio/inicio.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/inicio/inicio.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"gob\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button color=\"light\"></ion-menu-button>\n    </ion-buttons>\n    <ion-title>COVID-19 SV</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"primary\">\n      <ion-title size=\"large\">COVID-19 SV</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <div id=\"container\">\n    <div class=\"ion-padding\" style=\"padding-bottom: 0;\">\n        <strong class=\"capitalize\">COVID-19</strong>\n        <p>Seguimiento a tus sintomas de esta pandemia</p>\n        <ion-grid>\n            <ion-row>\n              <ion-col offset=\"3\" size=\"2\">\n                  <ion-fab-button size=\"small\" color=\"light\">\n                      <ion-icon name=\"person-outline\"></ion-icon>\n                    </ion-fab-button>\n              </ion-col>\n              <ion-col size=\"2\">\n                      <ion-fab-button [routerLink]=\"['/main/estadisticas']\" size=\"small\" color=\"light\">\n                          <ion-icon name=\"bar-chart-outline\"></ion-icon>\n                      </ion-fab-button>\n              </ion-col>\n              <ion-col size=\"2\">\n                  <ion-fab-button [routerLink]=\"['/main/ayuda']\" size=\"small\" color=\"light\">\n                      <ion-icon name=\"help-outline\"></ion-icon>\n                    </ion-fab-button>\n              </ion-col>\n              <ion-col size=\"3\"></ion-col>\n            </ion-row>\n          </ion-grid>\n    </div>\n    \n    <div *ngIf=\"ultimosReportes\">\n\n      <ion-card color=\"gob-light\">\n        <ion-item color=\"gob-light\" lines=\"none\" (click)=\"doEvaluation()\">\n          <ion-label>\n            <h2><strong>HOY</strong></h2>\n            <h4>{{ dias[6] }}</h4>\n          </ion-label>\n          <ion-icon \n          [name]=\"(ultimosReportes['fiebre'][6]) ? 'checkmark-outline' : 'chevron-forward-outline'\" slot=\"end\"\n          slot=\"end\"></ion-icon>\n          \n        </ion-item>\n    </ion-card>\n    <ion-card>\n        <ion-item lines=\"none\">\n          <ion-label>\n            <h2><strong>AYER</strong></h2>\n            <h4>{{ dias[5] }}</h4>\n          </ion-label>\n          <ion-icon \n          [name]=\"(ultimosReportes['fiebre'][5]) ? 'checkmark-outline' : 'close-outline'\" slot=\"end\" \n          [class]=\"(ultimosReportes['fiebre'][5]) ? 'checked' : 'incompleted'\"></ion-icon>\n        </ion-item>\n    </ion-card>\n    <ion-card class=\"history\">\n      <ion-list>\n        <ion-item>\n          <ion-label>\n            <h6><strong class=\"day\">{{ capitalize(dias[4][1]) }}</strong><small> {{ dias[4][0] }}</small></h6>\n          </ion-label>\n          <ion-icon \n          [name]=\"(ultimosReportes['fiebre'][4]) ? 'checkmark-outline' : 'close-outline'\" slot=\"end\"\n          [class]=\"(ultimosReportes['fiebre'][4]) ? 'checked__small' : 'incompleted__small'\"\n          ></ion-icon>\n        </ion-item>\n        <ion-item>\n          <ion-label>\n            <h6><strong class=\"day\">{{ capitalize(dias[3][1]) }}</strong><small> {{ dias[3][0] }}</small></h6>\n          </ion-label>\n          <ion-icon \n          [name]=\"(ultimosReportes['fiebre'][3]) ? 'checkmark-outline' : 'close-outline'\" slot=\"end\"\n          [class]=\"(ultimosReportes['fiebre'][3]) ? 'checked__small' : 'incompleted__small'\"\n          ></ion-icon>\n        </ion-item>\n        <ion-item>\n          <ion-label>\n            <h6><strong class=\"day\">{{ capitalize(dias[2][1]) }}</strong><small> {{ dias[2][0] }}</small></h6>\n          </ion-label>\n          <ion-icon \n          [name]=\"(ultimosReportes['fiebre'][2]) ? 'checkmark-outline' : 'close-outline'\" slot=\"end\"\n          [class]=\"(ultimosReportes['fiebre'][2]) ? 'checked__small' : 'incompleted__small'\"\n          ></ion-icon>\n        </ion-item>\n        <ion-item>\n          <ion-label>\n            <h6><strong class=\"day\">{{ capitalize(dias[1][1]) }}</strong><small> {{ dias[1][0] }}</small></h6>\n          </ion-label>\n          <ion-icon \n          [name]=\"(ultimosReportes['fiebre'][1]) ? 'checkmark-outline' : 'close-outline'\" slot=\"end\"\n          [class]=\"(ultimosReportes['fiebre'][1]) ? 'checked__small' : 'incompleted__small'\"\n          ></ion-icon>\n        </ion-item>\n      </ion-list>\n    </ion-card>\n\n    </div>\n\n    \n    \n  </div>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/inicio/inicio-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/inicio/inicio-routing.module.ts ***!
  \*************************************************/
/*! exports provided: InicioPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InicioPageRoutingModule", function() { return InicioPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _inicio_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./inicio.page */ "./src/app/inicio/inicio.page.ts");




const routes = [
    {
        path: '',
        component: _inicio_page__WEBPACK_IMPORTED_MODULE_3__["InicioPage"]
    }
];
let InicioPageRoutingModule = class InicioPageRoutingModule {
};
InicioPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], InicioPageRoutingModule);



/***/ }),

/***/ "./src/app/inicio/inicio.module.ts":
/*!*****************************************!*\
  !*** ./src/app/inicio/inicio.module.ts ***!
  \*****************************************/
/*! exports provided: InicioPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InicioPageModule", function() { return InicioPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _inicio_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./inicio-routing.module */ "./src/app/inicio/inicio-routing.module.ts");
/* harmony import */ var _inicio_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./inicio.page */ "./src/app/inicio/inicio.page.ts");







let InicioPageModule = class InicioPageModule {
};
InicioPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _inicio_routing_module__WEBPACK_IMPORTED_MODULE_5__["InicioPageRoutingModule"]
        ],
        declarations: [_inicio_page__WEBPACK_IMPORTED_MODULE_6__["InicioPage"]]
    })
], InicioPageModule);



/***/ }),

/***/ "./src/app/inicio/inicio.page.scss":
/*!*****************************************!*\
  !*** ./src/app/inicio/inicio.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  margin-top: 20px;\n}\n\n.capitalize {\n  font-size: 28px !important;\n  color: #3b3b3b;\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\nion-content ion-toolbar {\n  --background: transparent;\n}\n\n.checked, .checked__small {\n  padding: 5px;\n  background-color: #61cc72;\n  color: white;\n  border-radius: 50%;\n}\n\n.checked__small {\n  font-size: 14px;\n}\n\n.incompleted, .incompleted__small {\n  padding: 5px;\n  background-color: #cc6161;\n  color: white;\n  border-radius: 50%;\n}\n\n.incompleted__small {\n  font-size: 14px;\n}\n\n.history {\n  margin-top: 35px;\n}\n\n.history .day {\n  color: #3b3b3b;\n  font-size: 16px !important;\n  margin-right: 3px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9yb290L0RvY3VtZW50b3MvUHJveWVjdG9zL0lvbmljL3NlZ3VpbWllbnRvLWNvdmlkLTE5L3NyYy9hcHAvaW5pY2lvL2luaWNpby5wYWdlLnNjc3MiLCJzcmMvYXBwL2luaWNpby9pbmljaW8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsK0JBQUE7QUNDRjs7QURFQTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLGdCQUFBO0FDQ0Y7O0FEQ0E7RUFDRSwwQkFBQTtFQUNBLGNBQUE7QUNFRjs7QURBQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtBQ0dGOztBREFBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLFNBQUE7QUNHRjs7QURBQTtFQUNFLHFCQUFBO0FDR0Y7O0FEQUE7RUFDRSx5QkFBQTtBQ0dGOztBRERBO0VBQ0UsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDSUY7O0FERkE7RUFFRSxlQUFBO0FDSUY7O0FEREE7RUFDRSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUNJRjs7QURGQTtFQUVFLGVBQUE7QUNJRjs7QUREQTtFQUNFLGdCQUFBO0FDSUY7O0FESEU7RUFDRSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxpQkFBQTtBQ0tKIiwiZmlsZSI6InNyYy9hcHAvaW5pY2lvL2luaWNpby5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudS1idXR0b24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4jY29udGFpbmVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuLmNhcGl0YWxpemUge1xuICBmb250LXNpemU6IDI4cHggIWltcG9ydGFudDtcbiAgY29sb3I6ICMzYjNiM2I7XG59XG4jY29udGFpbmVyIHN0cm9uZyB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbGluZS1oZWlnaHQ6IDI2cHg7XG59XG5cbiNjb250YWluZXIgcCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGluZS1oZWlnaHQ6IDIycHg7XG4gIGNvbG9yOiAjOGM4YzhjO1xuICBtYXJnaW46IDA7XG59XG5cbiNjb250YWluZXIgYSB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn1cblxuaW9uLWNvbnRlbnQgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuLmNoZWNrZWQge1xuICBwYWRkaW5nOiA1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICM2MWNjNzI7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuLmNoZWNrZWRfX3NtYWxsIHtcbiAgQGV4dGVuZCAuY2hlY2tlZDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG4uaW5jb21wbGV0ZWQge1xuICBwYWRkaW5nOiA1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNjYzYxNjE7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuLmluY29tcGxldGVkX19zbWFsbCB7XG4gIEBleHRlbmQgLmluY29tcGxldGVkO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5oaXN0b3J5IHtcbiAgbWFyZ2luLXRvcDogMzVweDtcbiAgLmRheSB7XG4gICAgY29sb3I6ICMzYjNiM2I7XG4gICAgZm9udC1zaXplOiAxNnB4ICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLXJpZ2h0OiAzcHg7XG4gIH1cbn0iLCJpb24tbWVudS1idXR0b24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4jY29udGFpbmVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuXG4uY2FwaXRhbGl6ZSB7XG4gIGZvbnQtc2l6ZTogMjhweCAhaW1wb3J0YW50O1xuICBjb2xvcjogIzNiM2IzYjtcbn1cblxuI2NvbnRhaW5lciBzdHJvbmcge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGxpbmUtaGVpZ2h0OiAyNnB4O1xufVxuXG4jY29udGFpbmVyIHAge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICBjb2xvcjogIzhjOGM4YztcbiAgbWFyZ2luOiAwO1xufVxuXG4jY29udGFpbmVyIGEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG5cbmlvbi1jb250ZW50IGlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuLmNoZWNrZWQsIC5jaGVja2VkX19zbWFsbCB7XG4gIHBhZGRpbmc6IDVweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzYxY2M3MjtcbiAgY29sb3I6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG59XG5cbi5jaGVja2VkX19zbWFsbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLmluY29tcGxldGVkLCAuaW5jb21wbGV0ZWRfX3NtYWxsIHtcbiAgcGFkZGluZzogNXB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjY2M2MTYxO1xuICBjb2xvcjogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuLmluY29tcGxldGVkX19zbWFsbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuLmhpc3Rvcnkge1xuICBtYXJnaW4tdG9wOiAzNXB4O1xufVxuLmhpc3RvcnkgLmRheSB7XG4gIGNvbG9yOiAjM2IzYjNiO1xuICBmb250LXNpemU6IDE2cHggIWltcG9ydGFudDtcbiAgbWFyZ2luLXJpZ2h0OiAzcHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/inicio/inicio.page.ts":
/*!***************************************!*\
  !*** ./src/app/inicio/inicio.page.ts ***!
  \***************************************/
/*! exports provided: InicioPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InicioPage", function() { return InicioPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _services_reportes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/reportes.service */ "./src/app/services/reportes.service.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");








let InicioPage = class InicioPage {
    constructor(activatedRoute, router, storage, reportes, toast, alert) {
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.storage = storage;
        this.reportes = reportes;
        this.toast = toast;
        this.alert = alert;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.getReports();
    }
    getReports() {
        this.folder = this.activatedRoute.snapshot.paramMap.get('id');
        this.reportes.getLastReports().then(reportes => {
            reportes.subscribe(r => {
                this.ultimosReportes = r;
            });
        });
        this.fechaDeHoy = new Date();
        moment__WEBPACK_IMPORTED_MODULE_5__["lang"]("es");
        this.dias = [
            [this.formatted_day(6), this.formatted_day(6, "dddd")],
            [this.formatted_day(5), this.formatted_day(5, "dddd")],
            [this.formatted_day(4), this.formatted_day(4, "dddd")],
            [this.formatted_day(3), this.formatted_day(3, "dddd")],
            [this.formatted_day(2), this.formatted_day(2, "dddd")],
            this.formatted_day(1),
            moment__WEBPACK_IMPORTED_MODULE_5__().format("DD MMM YYYY")
        ];
    }
    doEvaluation(again = false) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.ultimosReportes['fiebre'][6] && !again) {
                const alert = yield this.alert.create({
                    header: 'Ya has enviado tu informe este dia!',
                    message: `Agradecemos tu colaboración y esfuerzo, recuerda volver a enviar tu estado mañana.<br>
        Si deseas volver a realizar la evaluación presiona "Repetir"`,
                    buttons: [{
                            cssClass: 'secondary',
                            text: 'Repetir',
                            handler: () => {
                                this.doEvaluation(true);
                            }
                        }, {
                            cssClass: 'primary',
                            text: 'De Acuerdo'
                        }
                    ]
                });
                yield alert.present();
            }
            else {
                this.router.navigate(["/main/dolordecabeza"]);
            }
        });
    }
    formatted_day(days, format = "DD MMM YYYY") {
        return moment__WEBPACK_IMPORTED_MODULE_5__().subtract(days, 'd').format(format);
    }
    capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
};
InicioPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
    { type: _services_reportes_service__WEBPACK_IMPORTED_MODULE_4__["ReportesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] }
];
InicioPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-folder',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./inicio.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/inicio/inicio.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./inicio.page.scss */ "./src/app/inicio/inicio.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"],
        _services_reportes_service__WEBPACK_IMPORTED_MODULE_4__["ReportesService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"]])
], InicioPage);



/***/ })

}]);
//# sourceMappingURL=inicio-inicio-module-es2015.js.map