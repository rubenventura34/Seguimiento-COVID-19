(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["otros-otros-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/otros/otros.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/otros/otros.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n    <div class=\"container\">\n        <div class=\"ion-padding heading\">\n            <ion-text color=\"gob\">\n                <h1><strong>¿Presentas algún otro<br>Sintoma?</strong></h1>\n            </ion-text>\n            \n          </div>\n          <ion-item>\n              <ion-textarea rows=\"7\" [(ngModel)]=\"postData.otros\" placeholder=\"Describe brevemente (opcional)\">\n\n                </ion-textarea>\n          </ion-item>\n          \n          \n    </div>\n\n</ion-content>\n<ion-footer class=\"ion-no-border\">\n  <ion-toolbar>\n    <div class=\"ion-padding\">\n        <ion-button (click)=\"finalizar()\" expand=\"block\" color=\"primary\">\n            Finalizar\n          </ion-button>\n    </div>\n  </ion-toolbar>\n</ion-footer>\n\n");

/***/ }),

/***/ "./src/app/otros/otros-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/otros/otros-routing.module.ts ***!
  \***********************************************/
/*! exports provided: OtrosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtrosPageRoutingModule", function() { return OtrosPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _otros_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./otros.page */ "./src/app/otros/otros.page.ts");




const routes = [
    {
        path: '',
        component: _otros_page__WEBPACK_IMPORTED_MODULE_3__["OtrosPage"]
    }
];
let OtrosPageRoutingModule = class OtrosPageRoutingModule {
};
OtrosPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], OtrosPageRoutingModule);



/***/ }),

/***/ "./src/app/otros/otros.module.ts":
/*!***************************************!*\
  !*** ./src/app/otros/otros.module.ts ***!
  \***************************************/
/*! exports provided: OtrosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtrosPageModule", function() { return OtrosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _otros_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./otros-routing.module */ "./src/app/otros/otros-routing.module.ts");
/* harmony import */ var _otros_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./otros.page */ "./src/app/otros/otros.page.ts");







let OtrosPageModule = class OtrosPageModule {
};
OtrosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _otros_routing_module__WEBPACK_IMPORTED_MODULE_5__["OtrosPageRoutingModule"]
        ],
        declarations: [_otros_page__WEBPACK_IMPORTED_MODULE_6__["OtrosPage"]]
    })
], OtrosPageModule);



/***/ }),

/***/ "./src/app/otros/otros.page.scss":
/*!***************************************!*\
  !*** ./src/app/otros/otros.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".heading {\n  margin-top: 25px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9yb290L0RvY3VtZW50b3MvUHJveWVjdG9zL0lvbmljL3NlZ3VpbWllbnRvLWNvdmlkLTE5L3NyYy9hcHAvb3Ryb3Mvb3Ryb3MucGFnZS5zY3NzIiwic3JjL2FwcC9vdHJvcy9vdHJvcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvb3Ryb3Mvb3Ryb3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRpbmcge1xuICAgIG1hcmdpbi10b3A6IDI1cHg7XG59IiwiLmhlYWRpbmcge1xuICBtYXJnaW4tdG9wOiAyNXB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/otros/otros.page.ts":
/*!*************************************!*\
  !*** ./src/app/otros/otros.page.ts ***!
  \*************************************/
/*! exports provided: OtrosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtrosPage", function() { return OtrosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_reportes_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/reportes.service */ "./src/app/services/reportes.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");





let OtrosPage = class OtrosPage {
    constructor(router, route, reportes, loading, toast) {
        this.router = router;
        this.route = route;
        this.reportes = reportes;
        this.loading = loading;
        this.toast = toast;
        this.postData = {
            dolor_de_cabeza: '',
            fiebre: '',
            tos: '',
            otros: '',
        };
        this.route.queryParams.subscribe(params => {
            this.postData.dolor_de_cabeza = params.dolor_de_cabeza;
            this.postData.fiebre = params.fiebre;
            this.postData.tos = params.tos;
        });
    }
    ngOnInit() {
    }
    finalizar() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loading.create({
                message: 'Enviando reporte...'
            });
            loading.present();
            this.reportes.report(this.postData).then(r => {
                r.subscribe((result) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                    const toast = yield this.toast.create({
                        message: result["mensaje"],
                        duration: 2000
                    });
                    if (result["error"]) {
                        loading.dismiss();
                        this.router.navigate(['/main/Inicio']);
                    }
                    else {
                        loading.dismiss();
                        this.router.navigate(['/main/confirmacion']);
                    }
                    toast.present();
                }), (error) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                    loading.dismiss();
                    const toast = yield this.toast.create({
                        message: 'Error en la conexión.',
                        duration: 2000
                    });
                    toast.present();
                }));
            });
        });
    }
};
OtrosPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _services_reportes_service__WEBPACK_IMPORTED_MODULE_3__["ReportesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] }
];
OtrosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-otros',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./otros.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/otros/otros.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./otros.page.scss */ "./src/app/otros/otros.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _services_reportes_service__WEBPACK_IMPORTED_MODULE_3__["ReportesService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]])
], OtrosPage);



/***/ }),

/***/ "./src/app/services/reportes.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/reportes.service.ts ***!
  \**********************************************/
/*! exports provided: ReportesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReportesService", function() { return ReportesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./http.service */ "./src/app/services/http.service.ts");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.service */ "./src/app/services/auth.service.ts");




let ReportesService = class ReportesService {
    constructor(httpService, authService) {
        this.httpService = httpService;
        this.authService = authService;
        this.api_token = '';
        this.authService.getToken();
    }
    getLastReports() {
        return this.authService.getToken().then(token => {
            return this.httpService.get("getLastReports?api_token=" + token, null);
        });
    }
    report(postData) {
        return this.authService.getToken().then(token => {
            return this.httpService.post("reportar?api_token=" + token, postData);
        });
    }
};
ReportesService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] }
];
ReportesService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"],
        _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]])
], ReportesService);



/***/ })

}]);
//# sourceMappingURL=otros-otros-module-es2015.js.map