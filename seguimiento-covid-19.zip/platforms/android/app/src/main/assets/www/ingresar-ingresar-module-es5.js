function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ingresar-ingresar-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/ingresar/ingresar.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/ingresar/ingresar.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppIngresarIngresarPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content color=\"gob\">\n  <div class=\"ion-padding\">\n      <img src=\"assets/banner-covid-19v5.png\" alt=\"\" srcset=\"\">\n      \n      <h1 class=\"titulo\">Seguimiento<br>COVID-19</h1>\n\n        <ion-label position=\"stacked\">DUI</ion-label>\n        <ion-input class=\"ion-border\" [(ngModel)]=\"postData.dui\" placeholder=\"Ingrese su numero de DUI\"></ion-input>\n      \n          <ion-label>Código de Acceso</ion-label>\n          <ion-input class=\"ion-border\" [(ngModel)]=\"postData.codigo\" placeholder=\"Ingrese su código de acceso\"></ion-input>\n          \n          <br>\n\n          <ion-button color=\"light\" (click)=\"ingresar()\" expand=\"block\">\n            Ingresar\n          </ion-button>\n\n  </div>\n  \n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/ingresar/ingresar-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/ingresar/ingresar-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: IngresarPageRoutingModule */

  /***/
  function srcAppIngresarIngresarRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IngresarPageRoutingModule", function () {
      return IngresarPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ingresar_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./ingresar.page */
    "./src/app/ingresar/ingresar.page.ts");

    var routes = [{
      path: '',
      component: _ingresar_page__WEBPACK_IMPORTED_MODULE_3__["IngresarPage"]
    }];

    var IngresarPageRoutingModule = function IngresarPageRoutingModule() {
      _classCallCheck(this, IngresarPageRoutingModule);
    };

    IngresarPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], IngresarPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/ingresar/ingresar.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/ingresar/ingresar.module.ts ***!
    \*********************************************/

  /*! exports provided: IngresarPageModule */

  /***/
  function srcAppIngresarIngresarModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IngresarPageModule", function () {
      return IngresarPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ingresar_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./ingresar-routing.module */
    "./src/app/ingresar/ingresar-routing.module.ts");
    /* harmony import */


    var _ingresar_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./ingresar.page */
    "./src/app/ingresar/ingresar.page.ts");

    var IngresarPageModule = function IngresarPageModule() {
      _classCallCheck(this, IngresarPageModule);
    };

    IngresarPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _ingresar_routing_module__WEBPACK_IMPORTED_MODULE_5__["IngresarPageRoutingModule"]],
      declarations: [_ingresar_page__WEBPACK_IMPORTED_MODULE_6__["IngresarPage"]]
    })], IngresarPageModule);
    /***/
  },

  /***/
  "./src/app/ingresar/ingresar.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/ingresar/ingresar.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppIngresarIngresarPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".ion-border {\n  border: 1px solid white;\n  margin-bottom: 20px;\n  margin-top: 10px;\n}\n\n.ion-padding {\n  padding-top: 100px;\n}\n\n.titulo {\n  text-align: center;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9yb290L0RvY3VtZW50b3MvUHJveWVjdG9zL0lvbmljL3NlZ3VpbWllbnRvLWNvdmlkLTE5L3NyYy9hcHAvaW5ncmVzYXIvaW5ncmVzYXIucGFnZS5zY3NzIiwic3JjL2FwcC9pbmdyZXNhci9pbmdyZXNhci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUNDSjs7QURDQTtFQUNJLGtCQUFBO0FDRUo7O0FEQUE7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0FDR0oiLCJmaWxlIjoic3JjL2FwcC9pbmdyZXNhci9pbmdyZXNhci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaW9uLWJvcmRlciB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuLmlvbi1wYWRkaW5nIHtcbiAgICBwYWRkaW5nLXRvcDogMTAwcHg7XG59XG4udGl0dWxvIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59IiwiLmlvbi1ib3JkZXIge1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLmlvbi1wYWRkaW5nIHtcbiAgcGFkZGluZy10b3A6IDEwMHB4O1xufVxuXG4udGl0dWxvIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXdlaWdodDogYm9sZDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/ingresar/ingresar.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/ingresar/ingresar.page.ts ***!
    \*******************************************/

  /*! exports provided: IngresarPage */

  /***/
  function srcAppIngresarIngresarPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IngresarPage", function () {
      return IngresarPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../services/auth.service */
    "./src/app/services/auth.service.ts");
    /* harmony import */


    var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../services/storage.service */
    "./src/app/services/storage.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var IngresarPage = /*#__PURE__*/function () {
      function IngresarPage(auth, storage, router, loading, toast, menuCtrl) {
        _classCallCheck(this, IngresarPage);

        this.auth = auth;
        this.storage = storage;
        this.router = router;
        this.loading = loading;
        this.toast = toast;
        this.menuCtrl = menuCtrl;
        this.postData = {
          dui: '',
          codigo: ''
        };
      }

      _createClass(IngresarPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "validar",
        value: function validar() {
          var dui = this.postData.dui.trim();
          var codigo = this.postData.codigo.trim();
          return this.postData.dui && this.postData.codigo && dui.length > 0 && codigo.length > 0;
        }
      }, {
        key: "ingresar",
        value: function ingresar() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    if (!this.validar()) {
                      _context3.next = 6;
                      break;
                    }

                    _context3.next = 3;
                    return this.loading.create({
                      message: 'Ingresando...'
                    });

                  case 3:
                    loading = _context3.sent;
                    loading.present();
                    this.auth.login(this.postData).subscribe(function (res) {
                      return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                        var toast;
                        return regeneratorRuntime.wrap(function _callee$(_context) {
                          while (1) {
                            switch (_context.prev = _context.next) {
                              case 0:
                                if (!res.isValid) {
                                  _context.next = 7;
                                  break;
                                }

                                console.log(res.userData);
                                this.storage.store('userData', res.userData)["catch"](function (err) {
                                  console.log(err);
                                });
                                loading.dismiss();
                                this.router.navigate(['/main/Inicio'])["catch"](function (err) {
                                  return console.error(err);
                                });
                                _context.next = 12;
                                break;

                              case 7:
                                loading.dismiss();
                                _context.next = 10;
                                return this.toast.create({
                                  message: 'Los datos no son validos',
                                  duration: 2000
                                });

                              case 10:
                                toast = _context.sent;
                                toast.present();

                              case 12:
                              case "end":
                                return _context.stop();
                            }
                          }
                        }, _callee, this);
                      }));
                    }, function (error) {
                      return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                        var toast;
                        return regeneratorRuntime.wrap(function _callee2$(_context2) {
                          while (1) {
                            switch (_context2.prev = _context2.next) {
                              case 0:
                                loading.dismiss();
                                _context2.next = 3;
                                return this.toast.create({
                                  message: 'Error de red.',
                                  duration: 2000
                                });

                              case 3:
                                toast = _context2.sent;
                                toast.present();

                              case 5:
                              case "end":
                                return _context2.stop();
                            }
                          }
                        }, _callee2, this);
                      }));
                    });

                  case 6:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }]);

      return IngresarPage;
    }();

    IngresarPage.ctorParameters = function () {
      return [{
        type: _services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
      }, {
        type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"]
      }];
    };

    IngresarPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-ingresar',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./ingresar.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/ingresar/ingresar.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./ingresar.page.scss */
      "./src/app/ingresar/ingresar.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"], _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"]])], IngresarPage);
    /***/
  }
}]);
//# sourceMappingURL=ingresar-ingresar-module-es5.js.map