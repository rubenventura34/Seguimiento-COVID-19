function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["noticias-noticias-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/noticias/noticias.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/noticias/noticias.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppNoticiasNoticiasPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n    <ion-toolbar color=\"gob\">\n      <ion-buttons slot=\"start\">\n        <ion-menu-button color=\"light\"></ion-menu-button>\n      </ion-buttons>\n      <ion-title>Noticias</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n  <div class=\"ion-padding\">\n      <iframe src=\"https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fsalud.sv&tabs=timeline&width=340&height=500&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=false&appId=2933618816863675\"\n      width=\"500\"\n      height=\"500\"\n      style=\"border:none;overflow:hidden\" \n      scrolling=\"no\" frameborder=\"0\" \n      allowTransparency=\"true\" allow=\"encrypted-media\"></iframe>\n  </div>\n  \n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/noticias/noticias-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/noticias/noticias-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: NoticiasPageRoutingModule */

  /***/
  function srcAppNoticiasNoticiasRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NoticiasPageRoutingModule", function () {
      return NoticiasPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _noticias_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./noticias.page */
    "./src/app/noticias/noticias.page.ts");

    var routes = [{
      path: '',
      component: _noticias_page__WEBPACK_IMPORTED_MODULE_3__["NoticiasPage"]
    }];

    var NoticiasPageRoutingModule = function NoticiasPageRoutingModule() {
      _classCallCheck(this, NoticiasPageRoutingModule);
    };

    NoticiasPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], NoticiasPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/noticias/noticias.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/noticias/noticias.module.ts ***!
    \*********************************************/

  /*! exports provided: NoticiasPageModule */

  /***/
  function srcAppNoticiasNoticiasModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NoticiasPageModule", function () {
      return NoticiasPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _noticias_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./noticias-routing.module */
    "./src/app/noticias/noticias-routing.module.ts");
    /* harmony import */


    var _noticias_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./noticias.page */
    "./src/app/noticias/noticias.page.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");

    var NoticiasPageModule = function NoticiasPageModule() {
      _classCallCheck(this, NoticiasPageModule);
    };

    NoticiasPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _noticias_routing_module__WEBPACK_IMPORTED_MODULE_5__["NoticiasPageRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"]],
      declarations: [_noticias_page__WEBPACK_IMPORTED_MODULE_6__["NoticiasPage"]]
    })], NoticiasPageModule);
    /***/
  },

  /***/
  "./src/app/noticias/noticias.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/noticias/noticias.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppNoticiasNoticiasPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL25vdGljaWFzL25vdGljaWFzLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/noticias/noticias.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/noticias/noticias.page.ts ***!
    \*******************************************/

  /*! exports provided: NoticiasPage */

  /***/
  function srcAppNoticiasNoticiasPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NoticiasPage", function () {
      return NoticiasPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js"); //import 'rxjs/add/operator/map';
    //import xml2js from 'xml2js';
    //declare var RSSParser;


    var NoticiasPage = /*#__PURE__*/function () {
      function NoticiasPage(http) {
        _classCallCheck(this, NoticiasPage);

        this.http = http;
        this.twitterUrl = 'https://twitter.com/saludsv';
        this.account = 'presidente';
      }

      _createClass(NoticiasPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "changeAccount",
        value: function changeAccount() {
          switch (this.account) {
            case 'presidente':
              this.twitterUrl = 'https://twitter.com/nayibbukele';
              break;

            case 'salud':
              this.twitterUrl = 'https://twitter.com/saludsv';
              break;

            case 'ministro':
              this.twitterUrl = 'https://twitter.com/franalabi';
              break;

            case 'prensa':
              this.twitterUrl = 'https://twitter.com/secprensasv';
              break;

            default:
              break;
          }
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {}
      }]);

      return NoticiasPage;
    }();

    NoticiasPage.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    NoticiasPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-noticias',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./noticias.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/noticias/noticias.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./noticias.page.scss */
      "./src/app/noticias/noticias.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], NoticiasPage);
    /***/
  }
}]);
//# sourceMappingURL=noticias-noticias-module-es5.js.map