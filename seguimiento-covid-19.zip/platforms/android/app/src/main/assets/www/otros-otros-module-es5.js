function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["otros-otros-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/otros/otros.page.html":
  /*!*****************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/otros/otros.page.html ***!
    \*****************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppOtrosOtrosPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\n    <div class=\"container\">\n        <div class=\"ion-padding heading\">\n            <ion-text color=\"gob\">\n                <h1><strong>¿Presentas algún otro<br>Sintoma?</strong></h1>\n            </ion-text>\n            \n          </div>\n          <ion-item>\n              <ion-textarea rows=\"7\" [(ngModel)]=\"postData.otros\" placeholder=\"Describe brevemente (opcional)\">\n\n                </ion-textarea>\n          </ion-item>\n          \n          \n    </div>\n\n</ion-content>\n<ion-footer class=\"ion-no-border\">\n  <ion-toolbar>\n    <div class=\"ion-padding\">\n        <ion-button (click)=\"finalizar()\" expand=\"block\" color=\"primary\">\n            Finalizar\n          </ion-button>\n    </div>\n  </ion-toolbar>\n</ion-footer>\n\n";
    /***/
  },

  /***/
  "./src/app/otros/otros-routing.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/otros/otros-routing.module.ts ***!
    \***********************************************/

  /*! exports provided: OtrosPageRoutingModule */

  /***/
  function srcAppOtrosOtrosRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OtrosPageRoutingModule", function () {
      return OtrosPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _otros_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./otros.page */
    "./src/app/otros/otros.page.ts");

    var routes = [{
      path: '',
      component: _otros_page__WEBPACK_IMPORTED_MODULE_3__["OtrosPage"]
    }];

    var OtrosPageRoutingModule = function OtrosPageRoutingModule() {
      _classCallCheck(this, OtrosPageRoutingModule);
    };

    OtrosPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], OtrosPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/otros/otros.module.ts":
  /*!***************************************!*\
    !*** ./src/app/otros/otros.module.ts ***!
    \***************************************/

  /*! exports provided: OtrosPageModule */

  /***/
  function srcAppOtrosOtrosModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OtrosPageModule", function () {
      return OtrosPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _otros_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./otros-routing.module */
    "./src/app/otros/otros-routing.module.ts");
    /* harmony import */


    var _otros_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./otros.page */
    "./src/app/otros/otros.page.ts");

    var OtrosPageModule = function OtrosPageModule() {
      _classCallCheck(this, OtrosPageModule);
    };

    OtrosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _otros_routing_module__WEBPACK_IMPORTED_MODULE_5__["OtrosPageRoutingModule"]],
      declarations: [_otros_page__WEBPACK_IMPORTED_MODULE_6__["OtrosPage"]]
    })], OtrosPageModule);
    /***/
  },

  /***/
  "./src/app/otros/otros.page.scss":
  /*!***************************************!*\
    !*** ./src/app/otros/otros.page.scss ***!
    \***************************************/

  /*! exports provided: default */

  /***/
  function srcAppOtrosOtrosPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".heading {\n  margin-top: 25px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9yb290L0RvY3VtZW50b3MvUHJveWVjdG9zL0lvbmljL3NlZ3VpbWllbnRvLWNvdmlkLTE5L3NyYy9hcHAvb3Ryb3Mvb3Ryb3MucGFnZS5zY3NzIiwic3JjL2FwcC9vdHJvcy9vdHJvcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvb3Ryb3Mvb3Ryb3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRpbmcge1xuICAgIG1hcmdpbi10b3A6IDI1cHg7XG59IiwiLmhlYWRpbmcge1xuICBtYXJnaW4tdG9wOiAyNXB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/otros/otros.page.ts":
  /*!*************************************!*\
    !*** ./src/app/otros/otros.page.ts ***!
    \*************************************/

  /*! exports provided: OtrosPage */

  /***/
  function srcAppOtrosOtrosPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OtrosPage", function () {
      return OtrosPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_reportes_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../services/reportes.service */
    "./src/app/services/reportes.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var OtrosPage = /*#__PURE__*/function () {
      function OtrosPage(router, route, reportes, loading, toast) {
        var _this = this;

        _classCallCheck(this, OtrosPage);

        this.router = router;
        this.route = route;
        this.reportes = reportes;
        this.loading = loading;
        this.toast = toast;
        this.postData = {
          dolor_de_cabeza: '',
          fiebre: '',
          tos: '',
          otros: ''
        };
        this.route.queryParams.subscribe(function (params) {
          _this.postData.dolor_de_cabeza = params.dolor_de_cabeza;
          _this.postData.fiebre = params.fiebre;
          _this.postData.tos = params.tos;
        });
      }

      _createClass(OtrosPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "finalizar",
        value: function finalizar() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var _this2 = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.loading.create({
                      message: 'Enviando reporte...'
                    });

                  case 2:
                    loading = _context3.sent;
                    loading.present();
                    this.reportes.report(this.postData).then(function (r) {
                      r.subscribe(function (result) {
                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                          var toast;
                          return regeneratorRuntime.wrap(function _callee$(_context) {
                            while (1) {
                              switch (_context.prev = _context.next) {
                                case 0:
                                  _context.next = 2;
                                  return this.toast.create({
                                    message: result["mensaje"],
                                    duration: 2000
                                  });

                                case 2:
                                  toast = _context.sent;

                                  if (result["error"]) {
                                    loading.dismiss();
                                    this.router.navigate(['/main/Inicio']);
                                  } else {
                                    loading.dismiss();
                                    this.router.navigate(['/main/confirmacion']);
                                  }

                                  toast.present();

                                case 5:
                                case "end":
                                  return _context.stop();
                              }
                            }
                          }, _callee, this);
                        }));
                      }, function (error) {
                        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                          var toast;
                          return regeneratorRuntime.wrap(function _callee2$(_context2) {
                            while (1) {
                              switch (_context2.prev = _context2.next) {
                                case 0:
                                  loading.dismiss();
                                  _context2.next = 3;
                                  return this.toast.create({
                                    message: 'Error en la conexión.',
                                    duration: 2000
                                  });

                                case 3:
                                  toast = _context2.sent;
                                  toast.present();

                                case 5:
                                case "end":
                                  return _context2.stop();
                              }
                            }
                          }, _callee2, this);
                        }));
                      });
                    });

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }]);

      return OtrosPage;
    }();

    OtrosPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _services_reportes_service__WEBPACK_IMPORTED_MODULE_3__["ReportesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
      }];
    };

    OtrosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-otros',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./otros.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/otros/otros.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./otros.page.scss */
      "./src/app/otros/otros.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_reportes_service__WEBPACK_IMPORTED_MODULE_3__["ReportesService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]])], OtrosPage);
    /***/
  },

  /***/
  "./src/app/services/reportes.service.ts":
  /*!**********************************************!*\
    !*** ./src/app/services/reportes.service.ts ***!
    \**********************************************/

  /*! exports provided: ReportesService */

  /***/
  function srcAppServicesReportesServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReportesService", function () {
      return ReportesService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./http.service */
    "./src/app/services/http.service.ts");
    /* harmony import */


    var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./auth.service */
    "./src/app/services/auth.service.ts");

    var ReportesService = /*#__PURE__*/function () {
      function ReportesService(httpService, authService) {
        _classCallCheck(this, ReportesService);

        this.httpService = httpService;
        this.authService = authService;
        this.api_token = '';
        this.authService.getToken();
      }

      _createClass(ReportesService, [{
        key: "getLastReports",
        value: function getLastReports() {
          var _this3 = this;

          return this.authService.getToken().then(function (token) {
            return _this3.httpService.get("getLastReports?api_token=" + token, null);
          });
        }
      }, {
        key: "report",
        value: function report(postData) {
          var _this4 = this;

          return this.authService.getToken().then(function (token) {
            return _this4.httpService.post("reportar?api_token=" + token, postData);
          });
        }
      }]);

      return ReportesService;
    }();

    ReportesService.ctorParameters = function () {
      return [{
        type: _http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"]
      }, {
        type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }];
    };

    ReportesService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_http_service__WEBPACK_IMPORTED_MODULE_2__["HttpService"], _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]])], ReportesService);
    /***/
  }
}]);
//# sourceMappingURL=otros-otros-module-es5.js.map