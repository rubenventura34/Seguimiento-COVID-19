(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ingresar-ingresar-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/ingresar/ingresar.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/ingresar/ingresar.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content color=\"gob\">\n  <div class=\"ion-padding\">\n      <img src=\"assets/banner-covid-19v5.png\" alt=\"\" srcset=\"\">\n      \n      <h1 class=\"titulo\">Seguimiento<br>COVID-19</h1>\n\n        <ion-label position=\"stacked\">DUI</ion-label>\n        <ion-input class=\"ion-border\" [(ngModel)]=\"postData.dui\" placeholder=\"Ingrese su numero de DUI\"></ion-input>\n      \n          <ion-label>Código de Acceso</ion-label>\n          <ion-input class=\"ion-border\" [(ngModel)]=\"postData.codigo\" placeholder=\"Ingrese su código de acceso\"></ion-input>\n          \n          <br>\n\n          <ion-button color=\"light\" (click)=\"ingresar()\" expand=\"block\">\n            Ingresar\n          </ion-button>\n\n  </div>\n  \n</ion-content>\n");

/***/ }),

/***/ "./src/app/ingresar/ingresar-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/ingresar/ingresar-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: IngresarPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IngresarPageRoutingModule", function() { return IngresarPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ingresar_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ingresar.page */ "./src/app/ingresar/ingresar.page.ts");




const routes = [
    {
        path: '',
        component: _ingresar_page__WEBPACK_IMPORTED_MODULE_3__["IngresarPage"]
    }
];
let IngresarPageRoutingModule = class IngresarPageRoutingModule {
};
IngresarPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], IngresarPageRoutingModule);



/***/ }),

/***/ "./src/app/ingresar/ingresar.module.ts":
/*!*********************************************!*\
  !*** ./src/app/ingresar/ingresar.module.ts ***!
  \*********************************************/
/*! exports provided: IngresarPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IngresarPageModule", function() { return IngresarPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _ingresar_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ingresar-routing.module */ "./src/app/ingresar/ingresar-routing.module.ts");
/* harmony import */ var _ingresar_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ingresar.page */ "./src/app/ingresar/ingresar.page.ts");







let IngresarPageModule = class IngresarPageModule {
};
IngresarPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _ingresar_routing_module__WEBPACK_IMPORTED_MODULE_5__["IngresarPageRoutingModule"]
        ],
        declarations: [_ingresar_page__WEBPACK_IMPORTED_MODULE_6__["IngresarPage"]]
    })
], IngresarPageModule);



/***/ }),

/***/ "./src/app/ingresar/ingresar.page.scss":
/*!*********************************************!*\
  !*** ./src/app/ingresar/ingresar.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ion-border {\n  border: 1px solid white;\n  margin-bottom: 20px;\n  margin-top: 10px;\n}\n\n.ion-padding {\n  padding-top: 100px;\n}\n\n.titulo {\n  text-align: center;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9yb290L0RvY3VtZW50b3MvUHJveWVjdG9zL0lvbmljL3NlZ3VpbWllbnRvLWNvdmlkLTE5L3NyYy9hcHAvaW5ncmVzYXIvaW5ncmVzYXIucGFnZS5zY3NzIiwic3JjL2FwcC9pbmdyZXNhci9pbmdyZXNhci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUNDSjs7QURDQTtFQUNJLGtCQUFBO0FDRUo7O0FEQUE7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0FDR0oiLCJmaWxlIjoic3JjL2FwcC9pbmdyZXNhci9pbmdyZXNhci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaW9uLWJvcmRlciB7XG4gICAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuLmlvbi1wYWRkaW5nIHtcbiAgICBwYWRkaW5nLXRvcDogMTAwcHg7XG59XG4udGl0dWxvIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59IiwiLmlvbi1ib3JkZXIge1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLmlvbi1wYWRkaW5nIHtcbiAgcGFkZGluZy10b3A6IDEwMHB4O1xufVxuXG4udGl0dWxvIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXdlaWdodDogYm9sZDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/ingresar/ingresar.page.ts":
/*!*******************************************!*\
  !*** ./src/app/ingresar/ingresar.page.ts ***!
  \*******************************************/
/*! exports provided: IngresarPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IngresarPage", function() { return IngresarPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");






let IngresarPage = class IngresarPage {
    constructor(auth, storage, router, loading, toast, menuCtrl) {
        this.auth = auth;
        this.storage = storage;
        this.router = router;
        this.loading = loading;
        this.toast = toast;
        this.menuCtrl = menuCtrl;
        this.postData = {
            dui: '',
            codigo: ''
        };
    }
    ngOnInit() {
    }
    validar() {
        let dui = this.postData.dui.trim();
        let codigo = this.postData.codigo.trim();
        return (this.postData.dui &&
            this.postData.codigo &&
            dui.length > 0 &&
            codigo.length > 0);
    }
    ingresar() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.validar()) {
                const loading = yield this.loading.create({
                    message: 'Ingresando...'
                });
                loading.present();
                this.auth.login(this.postData).subscribe((res) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                    if (res.isValid) {
                        console.log(res.userData);
                        this.storage.store('userData', res.userData).catch(err => {
                            console.log(err);
                        });
                        loading.dismiss();
                        this.router.navigate(['/main/Inicio']).catch(err => console.error(err));
                    }
                    else {
                        loading.dismiss();
                        const toast = yield this.toast.create({
                            message: 'Los datos no son validos',
                            duration: 2000
                        });
                        toast.present();
                    }
                }), (error) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                    loading.dismiss();
                    const toast = yield this.toast.create({
                        message: 'Error de red.',
                        duration: 2000
                    });
                    toast.present();
                }));
            }
        });
    }
};
IngresarPage.ctorParameters = () => [
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"] }
];
IngresarPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-ingresar',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./ingresar.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/ingresar/ingresar.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./ingresar.page.scss */ "./src/app/ingresar/ingresar.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"],
        _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"]])
], IngresarPage);



/***/ })

}]);
//# sourceMappingURL=ingresar-ingresar-module-es2015.js.map