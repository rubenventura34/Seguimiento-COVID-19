function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["recomendaciones-recomendaciones-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/recomendaciones/recomendaciones.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/recomendaciones/recomendaciones.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRecomendacionesRecomendacionesPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n    <ion-toolbar color=\"gob\">\n      <ion-buttons slot=\"start\">\n        <ion-menu-button color=\"light\"></ion-menu-button>\n      </ion-buttons>\n      <ion-title>Recomendaciones</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n    <ion-card *ngFor=\"let recomendacion of recomendaciones\">\n      <ion-card-content>\n        <ion-row>\n          <ion-col size=\"4\">\n            <img src=\"assets/{{ recomendacion.icono }}\">\n          </ion-col>\n          <ion-col>\n              <h5 class=\"titulo\">{{ recomendacion.titulo }}</h5>\n              <p>{{ recomendacion.descripcion }}</p>          \n          </ion-col>\n        </ion-row>\n      </ion-card-content>\n    </ion-card>\n\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/recomendaciones/recomendaciones-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/recomendaciones/recomendaciones-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: RecomendacionesPageRoutingModule */

  /***/
  function srcAppRecomendacionesRecomendacionesRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RecomendacionesPageRoutingModule", function () {
      return RecomendacionesPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _recomendaciones_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./recomendaciones.page */
    "./src/app/recomendaciones/recomendaciones.page.ts");

    var routes = [{
      path: '',
      component: _recomendaciones_page__WEBPACK_IMPORTED_MODULE_3__["RecomendacionesPage"]
    }];

    var RecomendacionesPageRoutingModule = function RecomendacionesPageRoutingModule() {
      _classCallCheck(this, RecomendacionesPageRoutingModule);
    };

    RecomendacionesPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], RecomendacionesPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/recomendaciones/recomendaciones.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/recomendaciones/recomendaciones.module.ts ***!
    \***********************************************************/

  /*! exports provided: RecomendacionesPageModule */

  /***/
  function srcAppRecomendacionesRecomendacionesModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RecomendacionesPageModule", function () {
      return RecomendacionesPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _recomendaciones_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./recomendaciones-routing.module */
    "./src/app/recomendaciones/recomendaciones-routing.module.ts");
    /* harmony import */


    var _recomendaciones_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./recomendaciones.page */
    "./src/app/recomendaciones/recomendaciones.page.ts");

    var RecomendacionesPageModule = function RecomendacionesPageModule() {
      _classCallCheck(this, RecomendacionesPageModule);
    };

    RecomendacionesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _recomendaciones_routing_module__WEBPACK_IMPORTED_MODULE_5__["RecomendacionesPageRoutingModule"]],
      declarations: [_recomendaciones_page__WEBPACK_IMPORTED_MODULE_6__["RecomendacionesPage"]]
    })], RecomendacionesPageModule);
    /***/
  },

  /***/
  "./src/app/recomendaciones/recomendaciones.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/recomendaciones/recomendaciones.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRecomendacionesRecomendacionesPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".titulo {\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9yb290L0RvY3VtZW50b3MvUHJveWVjdG9zL0lvbmljL3NlZ3VpbWllbnRvLWNvdmlkLTE5L3NyYy9hcHAvcmVjb21lbmRhY2lvbmVzL3JlY29tZW5kYWNpb25lcy5wYWdlLnNjc3MiLCJzcmMvYXBwL3JlY29tZW5kYWNpb25lcy9yZWNvbWVuZGFjaW9uZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvcmVjb21lbmRhY2lvbmVzL3JlY29tZW5kYWNpb25lcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGl0dWxvIHtcbiAgICBjb2xvcjogYmxhY2s7XG59IiwiLnRpdHVsbyB7XG4gIGNvbG9yOiBibGFjaztcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/recomendaciones/recomendaciones.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/recomendaciones/recomendaciones.page.ts ***!
    \*********************************************************/

  /*! exports provided: RecomendacionesPage */

  /***/
  function srcAppRecomendacionesRecomendacionesPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RecomendacionesPage", function () {
      return RecomendacionesPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var RecomendacionesPage = /*#__PURE__*/function () {
      function RecomendacionesPage() {
        _classCallCheck(this, RecomendacionesPage);

        this.recomendaciones = [{
          titulo: 'Lávese las manos frecuentemente',
          descripcion: 'Lávese las manos con frecuencia con un desinfectante de manos a base de alcohol o con agua y jabón.',
          icono: '3.jpg'
        }, {
          titulo: 'Adopte medidas de higiene respiratoria',
          descripcion: 'Cúbrete la boca con el entrebazo al toser o estornudar',
          icono: '4.png'
        }, {
          titulo: 'Mantenga el distanciamiento social',
          descripcion: 'Evita todo tipo de aglomeraciones',
          icono: '2.jpg'
        }, {
          titulo: 'Evita contacto fisico',
          descripcion: 'No saludes de mano, beso, abrazo ni otro contacto fisico',
          icono: '5.png'
        }, {
          titulo: 'Quedate en casa',
          descripcion: 'Sal de casa solo cuando sea estrictamente necesario',
          icono: '1.jpg'
        }, {
          titulo: 'Mantén la calma',
          descripcion: 'Mantén la calma y evita el panico',
          icono: '6.png'
        }];
      }

      _createClass(RecomendacionesPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return RecomendacionesPage;
    }();

    RecomendacionesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-recomendaciones',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./recomendaciones.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/recomendaciones/recomendaciones.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./recomendaciones.page.scss */
      "./src/app/recomendaciones/recomendaciones.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], RecomendacionesPage);
    /***/
  }
}]);
//# sourceMappingURL=recomendaciones-recomendaciones-module-es5.js.map